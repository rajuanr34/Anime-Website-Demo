// Function of onclick to change episode

function changeEp(fileName) {
   let episode = document.querySelector('#video_player');
   episode.setAttribute('src', fileName);
}